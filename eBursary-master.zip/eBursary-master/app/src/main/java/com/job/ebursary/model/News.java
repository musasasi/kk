package com.job.ebursary.model;

import android.graphics.drawable.Drawable;

public class News {

    public int image;
    public Drawable imageDrw;
    public String title;
    public String subtitle;
    public String date;
}
