package com.job.ebursary.model;

import android.graphics.drawable.Drawable;

public class Image {

    public int image;
    public Drawable imageDrw;
    public String name;
    public String brief;
    public String des;
    public Integer counter = null;

}
