package com.job.ebursary.commoners

interface PickerInterface {
    //false -> Gallery was picked
    fun picked(isCamera: Boolean)
}